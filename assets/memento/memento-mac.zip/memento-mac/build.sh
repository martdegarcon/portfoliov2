#!/bin/bash
# Собирает Memento.app и ставит в «Программы». Запуск: bash build.sh
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v swiftc >/dev/null 2>&1; then
  echo "Нужны инструменты разработчика Apple. Запусти: xcode-select --install"
  echo "После установки снова выполни: bash build.sh"
  exit 1
fi

APP="build/Memento.app"
echo "→ Собираю…"
rm -rf build
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

swiftc -O -target "$(uname -m)-apple-macos13.0" src/main.swift \
  -o "$APP/Contents/MacOS/Memento" \
  -framework AppKit -framework WebKit -framework ServiceManagement

cp Info.plist "$APP/Contents/Info.plist"
cp -R web "$APP/Contents/Resources/web"
if [ -d icon/AppIcon.iconset ]; then
  iconutil -c icns icon/AppIcon.iconset -o "$APP/Contents/Resources/AppIcon.icns"
fi

xattr -cr "$APP"
codesign --force --deep --sign - "$APP" >/dev/null 2>&1

if [ -w /Applications ]; then DEST="/Applications"; else DEST="$HOME/Applications"; mkdir -p "$DEST"; fi
pkill -x Memento >/dev/null 2>&1 || true
rm -rf "$DEST/Memento.app"
cp -R "$APP" "$DEST/"

echo "✓ Установлено: $DEST/Memento.app"
open "$DEST/Memento.app"
