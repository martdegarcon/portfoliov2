// Memento — напоминалка о конечности времени для строки меню macOS.
// Нативная оболочка: строка меню, триггеры, окна. Интерфейс — web/ui.html и web/settings.html.

import AppKit
import WebKit
import ServiceManagement
import CoreAudio

// MARK: - Настройки

struct Settings: Codable {
    var birthDate = ""
    var horizonYears = 80
    var wake = "08:00"
    var sleep = "00:00"
    var distractMinutes = 10
    var pulseMin = 90
    var pulseMax = 150
    var distractions = ["youtube.com", "instagram.com", "tiktok.com", "vk.com", "x.com", "reddit.com", "Telegram"]
    var quietApps: [String] = []
    var quietWhenMic = true
    var launchAtLogin = false

    init() {}

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        let d = Settings()
        birthDate = try c.decodeIfPresent(String.self, forKey: .birthDate) ?? d.birthDate
        horizonYears = try c.decodeIfPresent(Int.self, forKey: .horizonYears) ?? d.horizonYears
        wake = try c.decodeIfPresent(String.self, forKey: .wake) ?? d.wake
        sleep = try c.decodeIfPresent(String.self, forKey: .sleep) ?? d.sleep
        distractMinutes = try c.decodeIfPresent(Int.self, forKey: .distractMinutes) ?? d.distractMinutes
        pulseMin = try c.decodeIfPresent(Int.self, forKey: .pulseMin) ?? d.pulseMin
        pulseMax = try c.decodeIfPresent(Int.self, forKey: .pulseMax) ?? d.pulseMax
        distractions = try c.decodeIfPresent([String].self, forKey: .distractions) ?? d.distractions
        quietApps = try c.decodeIfPresent([String].self, forKey: .quietApps) ?? d.quietApps
        quietWhenMic = try c.decodeIfPresent(Bool.self, forKey: .quietWhenMic) ?? d.quietWhenMic
        launchAtLogin = try c.decodeIfPresent(Bool.self, forKey: .launchAtLogin) ?? d.launchAtLogin
    }

    var isConfigured: Bool { !birthDate.isEmpty }
}

enum Store {
    static let defaults = UserDefaults.standard

    static func loadSettings() -> Settings {
        guard let data = defaults.data(forKey: "settings"),
              let s = try? JSONDecoder().decode(Settings.self, from: data) else { return Settings() }
        return s
    }

    static func saveSettings(_ s: Settings) {
        if let data = try? JSONEncoder().encode(s) { defaults.set(data, forKey: "settings") }
    }

    static var task: String {
        get { defaults.string(forKey: "task") ?? "" }
        set { defaults.set(newValue, forKey: "task") }
    }

    static var angleIndex: Int {
        get { defaults.integer(forKey: "angleIndex") }
        set { defaults.set(newValue, forKey: "angleIndex") }
    }

    static var lastShown: Date? {
        get { defaults.object(forKey: "lastShown") as? Date }
        set { defaults.set(newValue, forKey: "lastShown") }
    }
}

// MARK: - Журнал: локальный лог показов и реакций (для исследования в кейсе)

enum Journal {
    static var folder: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("Memento", isDirectory: true)
    }

    static var lastDebug = ""
    static var lastDebugAt = Date.distantPast

    // Причины пропуска пишем не чаще раза в минуту, чтобы журнал помогал разбирать «почему не сработало».
    static func debug(_ event: [String: Any]) {
        let key = event.description
        if key == lastDebug && Date().timeIntervalSince(lastDebugAt) < 60 { return }
        lastDebug = key
        lastDebugAt = Date()
        var e = event
        e["event"] = "debug"
        write(e)
    }

    static func write(_ event: [String: Any]) {
        var e = event
        e["at"] = ISO8601DateFormatter().string(from: Date())
        guard let data = try? JSONSerialization.data(withJSONObject: e),
              let text = String(data: data, encoding: .utf8),
              let line = (text + "\n").data(using: .utf8) else { return }
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let url = folder.appendingPathComponent("log.jsonl")
        if let handle = try? FileHandle(forWritingTo: url) {
            handle.seekToEndOfFile()
            handle.write(line)
            try? handle.close()
        } else {
            try? line.write(to: url)
        }
    }
}

// MARK: - Время

func minutesOf(_ hhmm: String) -> Int {
    let parts = hhmm.split(separator: ":").compactMap { Int($0) }
    guard parts.count == 2 else { return 0 }
    return parts[0] * 60 + parts[1]
}

func wakeState(_ s: Settings, at now: Date = Date()) -> (awake: Bool, minutesToSleep: Int) {
    let comps = Calendar.current.dateComponents([.hour, .minute], from: now)
    let n = (comps.hour ?? 0) * 60 + (comps.minute ?? 0)
    let w = minutesOf(s.wake), sl = minutesOf(s.sleep)
    let awake = sl > w ? (n >= w && n < sl) : (n >= w || n < sl)
    return (awake, (sl - n + 1440) % 1440)
}

// MARK: - Триггер

struct Trigger {
    enum Kind: String { case distract, pulse, manual, snooze }
    var kind: Kind
    var label = ""
    var isSite = false
    var minutes = 0
}

struct Signal {
    var trigger: Trigger
    var started: Date
    var showAt: Date
}

// MARK: - Окно встряски

final class KeyPanel: NSPanel {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { true }
}

// MARK: - Приложение

final class AppDelegate: NSObject, NSApplicationDelegate, WKScriptMessageHandler, NSWindowDelegate {
    let panelWidth: CGFloat = 496
    let chromiumBrowsers: Set<String> = [
        "com.google.Chrome", "company.thebrowser.Browser", "com.brave.Browser", "com.microsoft.edgemac",
        "ru.yandex.desktop.yandex-browser", "com.vivaldi.Vivaldi", "com.operasoftware.Opera"
    ]

    var settings = Store.loadSettings()
    var statusItem: NSStatusItem!
    var panel: KeyPanel!
    var web: WKWebView!
    var webReady = false
    var pendingScript: String?
    var waitingToShow = false
    var shownAt: Date?
    var currentTrigger: Trigger?

    var settingsWindow: NSWindow?
    var settingsWeb: WKWebView?

    var signal: Signal? {
        didSet {
            if signal != nil && blinkTimer == nil {
                blinkTimer = Timer.scheduledTimer(timeInterval: 0.7, target: self, selector: #selector(blink), userInfo: nil, repeats: true)
            } else if signal == nil {
                blinkTimer?.invalidate()
                blinkTimer = nil
                blinkOn = false
            }
        }
    }
    var blinkTimer: Timer?
    var blinkOn = false

    var distractHit: (label: String, isSite: Bool)?
    var distractStart: Date?
    var distractLastSeen: Date?
    var nextPulse = Date()
    var snoozeUntil: Date?
    var pausedUntil: Date?
    var tickTimer: Timer?

    lazy var accent: NSColor = NSColor(name: nil) { appearance in
        appearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua
            ? NSColor(srgbRed: 0.85, green: 0.96, blue: 0.36, alpha: 1)
            : NSColor(srgbRed: 0.38, green: 0.50, blue: 0.0, alpha: 1)
    }

    // MARK: Запуск

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        buildMainMenu()

        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        if let button = statusItem.button {
            button.target = self
            button.action = #selector(statusClicked)
            button.sendAction(on: [.leftMouseUp, .rightMouseUp])
        }

        buildPanel()
        scheduleNextPulse()
        let timer = Timer(timeInterval: 10, target: self, selector: #selector(tick), userInfo: nil, repeats: true)
        RunLoop.main.add(timer, forMode: .common)
        tickTimer = timer
        updateStatus()
        Journal.write(["event": "launch"])

        if !settings.isConfigured { openSettings() }
    }

    // Без главного меню в текстовых полях не работают ⌘C / ⌘V / ⌘A.
    func buildMainMenu() {
        let main = NSMenu()
        let appItem = NSMenuItem()
        main.addItem(appItem)
        let appMenu = NSMenu()
        appMenu.addItem(withTitle: "Выйти Memento", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        appItem.submenu = appMenu

        let editItem = NSMenuItem()
        main.addItem(editItem)
        let edit = NSMenu(title: "Правка")
        edit.addItem(withTitle: "Отменить", action: Selector(("undo:")), keyEquivalent: "z")
        edit.addItem(withTitle: "Повторить", action: Selector(("redo:")), keyEquivalent: "Z")
        edit.addItem(.separator())
        edit.addItem(withTitle: "Вырезать", action: #selector(NSText.cut(_:)), keyEquivalent: "x")
        edit.addItem(withTitle: "Копировать", action: #selector(NSText.copy(_:)), keyEquivalent: "c")
        edit.addItem(withTitle: "Вставить", action: #selector(NSText.paste(_:)), keyEquivalent: "v")
        edit.addItem(withTitle: "Выделить всё", action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")
        editItem.submenu = edit
        NSApp.mainMenu = main
    }

    func makeWeb(page: String) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.userContentController.add(self, name: "memento")
        let view = WKWebView(frame: .zero, configuration: config)
        view.setValue(false, forKey: "drawsBackground")
        if let dir = Bundle.main.resourceURL?.appendingPathComponent("web", isDirectory: true) {
            view.loadFileURL(dir.appendingPathComponent(page), allowingReadAccessTo: dir)
        }
        return view
    }

    func buildPanel() {
        panel = KeyPanel(contentRect: NSRect(x: 0, y: 0, width: panelWidth, height: 720),
                         styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        panel.isFloatingPanel = true
        panel.level = .floating
        panel.backgroundColor = .clear
        panel.isOpaque = false
        panel.hasShadow = false
        panel.hidesOnDeactivate = false
        panel.isReleasedWhenClosed = false
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        web = makeWeb(page: "ui.html")
        if let content = panel.contentView {
            web.frame = content.bounds
            web.autoresizingMask = [.width, .height]
            content.addSubview(web)
        }
    }

    // MARK: Строка меню

    func hoursText() -> String {
        guard settings.isConfigured else { return "Memento" }
        let w = wakeState(settings)
        if !w.awake { return "сон" }
        let h = w.minutesToSleep / 60
        return h >= 1 ? "\(h) ч" : "\(w.minutesToSleep) мин"
    }

    func updateStatus() {
        guard let button = statusItem?.button else { return }
        var text = hoursText()
        let task = Store.task
        if let s = signal {
            // Во время сигнала строка меню объясняет, почему мигает точка.
            if s.trigger.kind == .distract {
                let t = currentTriggerFromSignal(s)
                text = "\(t.minutes) мин \(t.isSite ? "на" : "в") \(t.label)"
            } else {
                text = "Время оглянуться"
            }
        } else if !task.isEmpty {
            let short = task.count > 22 ? String(task.prefix(21)) + "…" : task
            text = "\(short) · \(text)"
        }
        let font = NSFont.menuBarFont(ofSize: 0)
        let dotColor: NSColor
        if signal != nil {
            dotColor = blinkOn ? accent : accent.withAlphaComponent(0.3)
        } else if let p = pausedUntil, p > Date() {
            dotColor = NSColor.labelColor.withAlphaComponent(0.3)
        } else {
            dotColor = NSColor.labelColor.withAlphaComponent(0.6)
        }
        let title = NSMutableAttributedString()
        title.append(NSAttributedString(string: signal != nil ? "● " : "◐ ", attributes: [.font: font, .foregroundColor: dotColor]))
        title.append(NSAttributedString(string: text, attributes: [.font: font, .foregroundColor: NSColor.labelColor]))
        button.attributedTitle = title
    }

    @objc func blink() {
        blinkOn.toggle()
        updateStatus()
    }

    @objc func statusClicked() {
        if let s = signal {
            showPanel(currentTriggerFromSignal(s))
            return
        }
        statusItem.menu = buildMenu()
        statusItem.button?.performClick(nil)
        statusItem.menu = nil
    }

    func menuItem(_ title: String, _ action: Selector?, _ key: String = "") -> NSMenuItem {
        let item = NSMenuItem(title: title, action: action, keyEquivalent: key)
        item.target = self
        if action == nil { item.isEnabled = false }
        return item
    }

    func buildMenu() -> NSMenu {
        let menu = NSMenu()
        menu.autoenablesItems = false
        let task = Store.task
        menu.addItem(menuItem(task.isEmpty ? "Задача не выбрана" : "Сейчас: \(task)", nil))
        if settings.isConfigured {
            let w = wakeState(settings)
            let info = w.awake ? "До сна \(w.minutesToSleep / 60) ч \(w.minutesToSleep % 60) мин" : "Время сна — встряски выключены"
            menu.addItem(menuItem(info, nil))
        }
        if let hit = distractHit, let start = distractStart {
            let m = Int(Date().timeIntervalSince(start) / 60)
            menu.addItem(menuItem("\(hit.isSite ? "На" : "В") \(hit.label): \(m) из \(settings.distractMinutes) мин", nil))
        }
        menu.addItem(.separator())
        menu.addItem(menuItem("Показать календарь сейчас", #selector(shakeNow)))
        if let p = pausedUntil, p > Date() {
            let f = DateFormatter()
            f.dateFormat = "HH:mm"
            menu.addItem(menuItem("Снять паузу (до \(f.string(from: p)))", #selector(resume)))
        } else {
            menu.addItem(menuItem("Пауза на 1 час", #selector(pauseHour)))
        }
        if !task.isEmpty { menu.addItem(menuItem("Очистить задачу", #selector(clearTask))) }
        menu.addItem(.separator())
        menu.addItem(menuItem("Настройки…", #selector(openSettings), ","))
        menu.addItem(menuItem("Журнал встрясок", #selector(openJournal)))
        menu.addItem(.separator())
        menu.addItem(menuItem("Выйти", #selector(quit), "q"))
        return menu
    }

    @objc func shakeNow() { showPanel(Trigger(kind: .manual)) }

    @objc func pauseHour() {
        pausedUntil = Date().addingTimeInterval(3600)
        signal = nil
        Journal.write(["event": "pause"])
        updateStatus()
    }

    @objc func resume() {
        pausedUntil = nil
        scheduleNextPulse()
        updateStatus()
    }

    @objc func clearTask() {
        Store.task = ""
        updateStatus()
    }

    @objc func openJournal() {
        try? FileManager.default.createDirectory(at: Journal.folder, withIntermediateDirectories: true)
        NSWorkspace.shared.open(Journal.folder)
    }

    @objc func quit() { NSApp.terminate(nil) }

    // MARK: Наблюдение

    func scheduleNextPulse(from now: Date = Date()) {
        if settings.pulseMin <= 0 { nextPulse = .distantFuture; return }
        let lo = max(15, settings.pulseMin)
        let hi = max(lo, settings.pulseMax)
        nextPulse = now.addingTimeInterval(Double(Int.random(in: lo...hi)) * 60)
    }

    func activeHost(_ app: NSRunningApplication) -> String? {
        guard let bid = app.bundleIdentifier else { return nil }
        let source: String
        if bid == "com.apple.Safari" {
            source = "tell application id \"com.apple.Safari\" to return URL of front document"
        } else if chromiumBrowsers.contains(bid) {
            source = "tell application id \"\(bid)\" to return URL of active tab of front window"
        } else {
            return nil
        }
        var error: NSDictionary?
        guard let script = NSAppleScript(source: source) else { return nil }
        let result = script.executeAndReturnError(&error)
        guard error == nil, let text = result.stringValue, let host = URL(string: text)?.host else { return nil }
        return host.lowercased()
    }

    func currentDistraction() -> (label: String, isSite: Bool)? {
        guard let app = NSWorkspace.shared.frontmostApplication else { return nil }
        let name = (app.localizedName ?? "").lowercased()
        let bid = (app.bundleIdentifier ?? "").lowercased()
        let host = activeHost(app)
        for raw in settings.distractions {
            let entry = raw.trimmingCharacters(in: .whitespaces).lowercased()
            if entry.isEmpty { continue }
            if let h = host, h == entry || h.hasSuffix("." + entry) { return (entry, true) }
            if entry == name || entry == bid { return (app.localizedName ?? raw, false) }
        }
        return nil
    }

    func inQuietApp() -> Bool {
        guard let app = NSWorkspace.shared.frontmostApplication else { return false }
        let name = (app.localizedName ?? "").lowercased()
        let bid = (app.bundleIdentifier ?? "").lowercased()
        return settings.quietApps.contains { raw in
            let e = raw.trimmingCharacters(in: .whitespaces).lowercased()
            return !e.isEmpty && (e == name || e == bid)
        }
    }

    // Звонок = микрофон кем-то используется. Работает для любых созвонов, в том числе в браузере.
    func micInUse() -> Bool {
        var device = AudioDeviceID(0)
        var size = UInt32(MemoryLayout<AudioDeviceID>.size)
        var address = AudioObjectPropertyAddress(mSelector: kAudioHardwarePropertyDefaultInputDevice,
                                                 mScope: kAudioObjectPropertyScopeGlobal,
                                                 mElement: kAudioObjectPropertyElementMain)
        guard AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &size, &device) == noErr,
              device != 0 else { return false }
        var running = UInt32(0)
        size = UInt32(MemoryLayout<UInt32>.size)
        address.mSelector = kAudioDevicePropertyDeviceIsRunningSomewhere
        guard AudioObjectGetPropertyData(device, &address, 0, nil, &size, &running) == noErr else { return false }
        return running != 0
    }

    func runningAppsPayload() -> [[String: String]] {
        let ownID = Bundle.main.bundleIdentifier
        var seen = Set<String>()
        var result: [[String: String]] = []
        for app in NSWorkspace.shared.runningApplications where app.activationPolicy == .regular {
            guard let name = app.localizedName, app.bundleIdentifier != ownID, !seen.contains(name) else { continue }
            seen.insert(name)
            var item = ["name": name, "bundleId": app.bundleIdentifier ?? ""]
            if let icon = app.icon {
                let target = NSSize(width: 40, height: 40)
                let image = NSImage(size: target)
                image.lockFocus()
                icon.draw(in: NSRect(origin: .zero, size: target))
                image.unlockFocus()
                if let tiff = image.tiffRepresentation,
                   let rep = NSBitmapImageRep(data: tiff),
                   let png = rep.representation(using: .png, properties: [:]) {
                    item["icon"] = "data:image/png;base64," + png.base64EncodedString()
                }
            }
            result.append(item)
        }
        return result.sorted { ($0["name"] ?? "").localizedCaseInsensitiveCompare($1["name"] ?? "") == .orderedAscending }
    }

    func screenLocked() -> Bool {
        guard let dict = CGSessionCopyCurrentDictionary() as NSDictionary? else { return false }
        return (dict["CGSSessionScreenIsLocked"] as? Bool) ?? false
    }

    func idleSeconds() -> Double {
        guard let any = CGEventType(rawValue: ~0) else { return 0 }
        return CGEventSource.secondsSinceLastEventType(.combinedSessionState, eventType: any)
    }

    func currentTriggerFromSignal(_ s: Signal) -> Trigger {
        var t = s.trigger
        if t.kind == .distract, let start = distractStart {
            t.minutes = max(t.minutes, Int(Date().timeIntervalSince(start) / 60))
        }
        return t
    }

    @objc func tick() {
        updateStatus()
        if waitingToShow, let at = shownAt, Date().timeIntervalSince(at) > 5 {
            // Страховка: окно так и не показалось — показываем принудительно.
            Journal.debug(["watchdog": "forcePresent"])
            presentPanel(height: panel.frame.height)
        }
        guard settings.isConfigured, !panel.isVisible, !waitingToShow else { return }
        let now = Date()

        if let p = pausedUntil {
            if now < p { return }
            pausedUntil = nil
            scheduleNextPulse(from: now)
        }
        if let s = snoozeUntil, now >= s {
            snoozeUntil = nil
            showPanel(Trigger(kind: .snooze))
            return
        }

        let awake = wakeState(settings, at: now).awake
        let quiet = inQuietApp() || (settings.quietWhenMic && micInUse())
        let hit = (awake && !quiet) ? currentDistraction() : nil
        // «Отошёл от компьютера» = экран заблокирован или долго нет действий.
        // Но если на экране отвлечение (видео), отсутствие действий — это и есть залипание, а не уход.
        let away = screenLocked() || (idleSeconds() > 180 && hit == nil)
        if !awake || away || quiet {
            if !awake { scheduleNextPulse(from: now) }
            if away { distractHit = nil; distractStart = nil; distractLastSeen = nil }
            if signal != nil { signal = nil; updateStatus() }
            Journal.debug(["skip": !awake ? "sleepHours" : (quiet ? "quiet" : "away")])
            return
        }

        // Отвлечение: считаем непрерывное время на сайте или в приложении из списка.
        if let hit = hit {
            if distractHit?.label != hit.label {
                distractHit = hit
                distractStart = now
            }
            distractLastSeen = now
        } else if let seen = distractLastSeen, now.timeIntervalSince(seen) > 45 {
            if let s = signal, s.trigger.kind == .distract {
                Journal.write(["event": "selfReturn", "label": s.trigger.label, "seconds": Int(now.timeIntervalSince(s.started))])
                signal = nil
                updateStatus()
            }
            distractHit = nil
            distractStart = nil
            distractLastSeen = nil
        }

        // Тихий сигнал уже идёт: по истечении паузы — окно.
        if let s = signal {
            if now >= s.showAt { showPanel(currentTriggerFromSignal(s)) }
            return
        }

        if let start = distractStart, let hit = distractHit,
           now.timeIntervalSince(start) >= Double(settings.distractMinutes * 60) {
            let minutes = Int(now.timeIntervalSince(start) / 60)
            beginSignal(Trigger(kind: .distract, label: hit.label, isSite: hit.isSite, minutes: minutes), delay: 90)
            return
        }

        if now >= nextPulse {
            beginSignal(Trigger(kind: .pulse), delay: 40)
        }
    }

    // Ступень 1: точка в строке меню мигает. Если человек сам ушёл с отвлечения — окно не нужно.
    func beginSignal(_ t: Trigger, delay: TimeInterval) {
        let now = Date()
        signal = Signal(trigger: t, started: now, showAt: now.addingTimeInterval(delay))
        Journal.write(["event": "signal", "trigger": t.kind.rawValue, "label": t.label])
        updateStatus()
    }

    // MARK: Окно встряски

    func nextAngle() -> String {
        let angles = ["life", "year", "day"]
        let i = Store.angleIndex % angles.count
        Store.angleIndex = i + 1
        return angles[i]
    }

    func settingsObject() -> Any {
        guard let data = try? JSONEncoder().encode(settings),
              let obj = try? JSONSerialization.jsonObject(with: data) else { return [String: Any]() }
        return obj
    }

    func jsonString(_ obj: Any) -> String? {
        guard let data = try? JSONSerialization.data(withJSONObject: obj) else { return nil }
        return String(data: data, encoding: .utf8)
    }

    func showPanel(_ t: Trigger) {
        guard settings.isConfigured else { openSettings(); return }
        signal = nil
        updateStatus()
        if panel.isVisible || waitingToShow {
            panel.orderFrontRegardless()
            panel.makeKey()
            return
        }
        // Пока окно на экране, отвлечение не копится заново.
        distractStart = distractHit == nil ? nil : Date()

        currentTrigger = t
        let angle = nextAngle()
        var trig: [String: Any] = ["kind": t.kind.rawValue, "label": t.label, "isSite": t.isSite, "minutes": t.minutes]
        if let last = Store.lastShown { trig["sinceLastMinutes"] = Int(Date().timeIntervalSince(last) / 60) }
        let payload: [String: Any] = [
            "settings": settingsObject(), "trigger": trig, "angle": angle,
            "task": Store.task, "now": Date().timeIntervalSince1970 * 1000
        ]
        guard let json = jsonString(payload) else { return }
        let script = "window.memento.show(\(json))"

        waitingToShow = true
        Store.lastShown = Date()
        shownAt = Date()
        Journal.write(["event": "shown", "trigger": t.kind.rawValue, "label": t.label, "angle": angle])

        if webReady {
            web.evaluateJavaScript(script, completionHandler: nil)
        } else {
            pendingScript = script
        }
        // Запасной путь, если страница не прислала размер.
        perform(#selector(presentIfWaiting), with: nil, afterDelay: 0.8)
    }

    @objc func presentIfWaiting() {
        if waitingToShow { presentPanel(height: panel.frame.height) }
    }

    func screenWithMouse() -> NSScreen? {
        let mouse = NSEvent.mouseLocation
        return NSScreen.screens.first { NSMouseInRect(mouse, $0.frame, false) } ?? NSScreen.main
    }

    func presentPanel(height: CGFloat) {
        waitingToShow = false
        guard let screen = screenWithMouse() else { return }
        let vf = screen.visibleFrame
        let h = min(height, vf.height)
        let origin = NSPoint(x: vf.midX - panelWidth / 2, y: vf.midY - h / 2)
        panel.setFrame(NSRect(origin: origin, size: NSSize(width: panelWidth, height: h)), display: true)
        // Панель не активирует приложение: так она появляется поверх всего даже в фоне
        // (macOS не даёт фоновым приложениям перехватывать фокус) и принимает ввод с клавиатуры.
        if NSApp.isHidden { NSApp.unhide(nil) }
        panel.orderFrontRegardless()
        panel.makeKey()
        panel.makeFirstResponder(web)
        Journal.write(["event": "presented", "visible": panel.isVisible])
        web.evaluateJavaScript("window.memento.focus()", completionHandler: nil)
    }

    func finish(_ action: String, task: String?) {
        guard panel.isVisible || waitingToShow else { return }
        let seconds = shownAt.map { Int(Date().timeIntervalSince($0)) } ?? 0
        if action == "return", let t = task?.trimmingCharacters(in: .whitespacesAndNewlines), !t.isEmpty {
            Store.task = t
        }
        if action == "snooze" { snoozeUntil = Date().addingTimeInterval(600) }
        Journal.write(["event": action, "trigger": currentTrigger?.kind.rawValue ?? "", "seconds": seconds, "task": Store.task])

        waitingToShow = false
        panel.orderOut(nil)
        distractHit = nil
        distractStart = nil
        distractLastSeen = nil
        scheduleNextPulse()
        updateStatus()
    }

    // MARK: Настройки

    @objc func openSettings() {
        if settingsWindow == nil {
            let w = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 540, height: 860),
                             styleMask: [.titled, .closable, .fullSizeContentView],
                             backing: .buffered, defer: false)
            w.titlebarAppearsTransparent = true
            w.titleVisibility = .hidden
            w.title = "Memento — настройки"
            w.appearance = NSAppearance(named: .darkAqua)
            w.backgroundColor = NSColor(srgbRed: 0.043, green: 0.043, blue: 0.051, alpha: 1)
            w.isReleasedWhenClosed = false
            w.delegate = self
            let view = makeWeb(page: "settings.html")
            w.contentView = view
            settingsWeb = view
            settingsWindow = w
            w.center()
        } else {
            sendSettingsToPage()
        }
        NSApp.activate(ignoringOtherApps: true)
        settingsWindow?.makeKeyAndOrderFront(nil)
    }

    func sendSettingsToPage() {
        let payload: [String: Any] = ["settings": settingsObject(), "firstRun": !settings.isConfigured]
        guard let json = jsonString(payload) else { return }
        settingsWeb?.evaluateJavaScript("window.memento.load(\(json))", completionHandler: nil)
    }

    func applySettings(_ s: Settings) {
        let wasConfigured = settings.isConfigured
        settings = s
        Store.saveSettings(s)

        let service = SMAppService.mainApp
        do {
            if s.launchAtLogin && service.status != .enabled { try service.register() }
            if !s.launchAtLogin && service.status == .enabled { try service.unregister() }
        } catch {
            NSLog("Memento: launch at login failed: \(error)")
        }

        scheduleNextPulse()
        updateStatus()
        settingsWindow?.close()
        Journal.write(["event": "settings"])
        if !wasConfigured { showPanel(Trigger(kind: .manual)) }
    }

    func windowWillClose(_ notification: Notification) {}

    // MARK: Сообщения из веб-интерфейса

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any], let type = body["type"] as? String else { return }
        let fromPanel = message.webView === web

        switch type {
        case "ready":
            if fromPanel {
                webReady = true
                if let script = pendingScript {
                    pendingScript = nil
                    web.evaluateJavaScript(script, completionHandler: nil)
                }
            } else {
                sendSettingsToPage()
            }
        case "size":
            if fromPanel, let h = (body["height"] as? NSNumber)?.doubleValue {
                let height = CGFloat(h)
                if waitingToShow {
                    presentPanel(height: height)
                } else if panel.isVisible {
                    var f = panel.frame
                    f.origin.y += f.height - height
                    f.size.height = height
                    panel.setFrame(f, display: true)
                }
            }
        case "return", "snooze", "close":
            finish(type, task: body["task"] as? String)
        case "saveSettings":
            if let obj = body["settings"],
               let data = try? JSONSerialization.data(withJSONObject: obj),
               let s = try? JSONDecoder().decode(Settings.self, from: data) {
                applySettings(s)
            }
        case "runningApps":
            if let json = jsonString(runningAppsPayload()) {
                settingsWeb?.evaluateJavaScript("window.memento.apps(\(json))", completionHandler: nil)
            }
        case "cancelSettings":
            settingsWindow?.close()
        default:
            break
        }
    }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.run()
